import os, sys, traceback, multiprocessing, arcpy, time

arcpy.ImportToolbox(r'C:\Program Files (x86)\Common Files\Esri\Roads and Highways\ToolBoxes\Roads And Highways Tools.tbx')

def splitArray(arr, count):
     return [arr[i::count] for i in range(count)]


def generateRouteCalibration(fc, outFolder, counter, routeIDFieldName, routeIDRange):
    layerName = os.path.basename(fc) + str(counter)
    newRouteLayer = layerName + '_route'
    queryString = '('
    for q in routeIDRange:
        queryString += '\'%s\',' % q
    queryString = queryString[0:len(queryString) - 1] + ')'
    whereClause = '%s IN %s' % (routeIDFieldName, queryString)
    arcpy.MakeFeatureLayer_management(fc, layerName, whereClause)
    #arcpy.SelectLayerByAttribute_management(layerName, 'NEW_SELECTION', '%s IN %s' % (routeIDFieldName, queryString))
    outShapeFile = arcpy.CreateScratchName(layerName,'','Shapefile', outFolder)
    outCalibrationSF = arcpy.CreateScratchName(layerName + '_cal','','Shapefile', outFolder)
    print 'Creating ' + outShapeFile
    arcpy.CopyFeatures_management(layerName, outShapeFile)
    print 'Created ' + outShapeFile
    arcpy.MakeFeatureLayer_management(outShapeFile, newRouteLayer)
    print 'Creating ' + outCalibrationSF
    #arcpy.GenerateCalibrationPoints_roads(newRouteLayer,routeIDFieldName,"M_ON_ROUTE_2D",outCalibrationSF)
    print 'Calibration point created ' + outCalibrationSF
    #return outCalibrationSF
    return outShapeFile

def main():
  # Create a pool class and run the jobs?the number of jobs is equal to the number of processors
    pool = None
    results = []
    arcpy.env.overwriteOutput = True
    try:
        row, rows = None, None
        inFC = 'D:/GIS Data/DOT/RouteBase_1.gdb/Rawbase/AllRoads';
        outFolder = 'D:/GIS Data/DOT/Shapefiles';
        routeIDFieldName = 'ROUTE_ID'
        print "Performing frequency"
        tempFrequencyTable = 'IN_MEMORY/RouteFrq1'
        arcpy.Frequency_analysis(inFC,tempFrequencyTable,routeIDFieldName)
        print "Frequency complete"
        rows = arcpy.SearchCursor(tempFrequencyTable)
        print "Cursor open"
        routeIDList = []
        for row in rows:
            routeIDList += [row.getValue(routeIDFieldName)]
        print 'Done with loop'
        routeIDChunks = splitArray(routeIDList, multiprocessing.cpu_count())
        results = []
        print 'Creating the pool'
        pool = multiprocessing.Pool()
        print 'Pool created'
        counter = 0
        for chunk in routeIDChunks:
            print "Submitted job " + str(counter)
            #Async call
            results += [pool.apply_async(generateRouteCalibration, (inFC, outFolder, counter, routeIDFieldName, chunk, ))]
            #synchronous call
            #results += [generateRouteCalibration(inFC, outFolder, counter, routeIDFieldName, chunk)]
            counter += 1
        #pool.map(generateRouteCalibration, routeIDList, multiprocessing.cpu_count())
    except:
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]

        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        msgs = "ArcPy ERRORS:\n" + arcpy.GetMessages(2) + "\n"

        # Return python error messages for use in script tool or Python Window
        arcpy.AddError(pymsg)
        arcpy.AddError(msgs)
        print pymsg
        print msgs
        time.sleep(10)
    finally:
        print 'Waiting for jobs to complete'
        if pool:
            pool.close()
            pool.join()
        print 'Cleaning up'
        if row:
            del row
        if rows:
            del rows
    outputFiles = []
    for result in results:
        outputFiles += [result.get(1)]
        print result.get(1)
        #print result

    print outputFiles
    #print 'Merging results'
    #arcpy.Merge_management(outputFiles, os.path.join(outFolder, "CalibrationPoints.shp"))
    print 'Done!'
  # Synchronize the main process with the job processes to ensure proper cleanup.

# End main
if __name__ == '__main__':
    main()
